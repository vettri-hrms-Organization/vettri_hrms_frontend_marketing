import PageShell from "@/components/PageShell";
import type { Metadata } from "next";

export const metadata: Metadata = {
	title: "Resources",
	description: "Practical guidance and product thinking for connected people and workplace operations.",
	alternates: { canonical: "/resources" },
	robots: { index: false, follow: true },
};

export default function ResourcesPage(){return <PageShell gradient="soft" eyebrow="Resources" title="A clearer way to think about connected work." intro="Guides, product updates, workplace insights and documentation will live here as Vettri grows." sections={[{title:"Guides",body:"Practical guidance for connecting people operations and workplace technology. Content collection coming soon."},{title:"Product updates",body:"A concise record of how Vettri evolves. No published updates are being represented yet."},{title:"Workplace insights",body:"Ideas for teams building more thoughtful, connected workplaces. Placeholder collection for the public site."}]}/>}
