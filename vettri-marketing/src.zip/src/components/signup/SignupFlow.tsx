"use client";

import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { ArrowLeft, ArrowRight, Check, Eye, EyeOff, LockKeyhole, ShieldCheck } from "lucide-react";
import { useState } from "react";
import { API_URL, APP_URL } from "@/lib/config";

type SignupStep = 1 | 2 | 3;
type Option = { value: string; label: string };

export interface SignupFormData {
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  role: string;
  organizationName: string;
  industry: string;
  companySize: string;
  country: string;
  interests: string[];
}

const initialData: SignupFormData = {
  firstName: "",
  lastName: "",
  email: "",
  password: "",
  role: "",
  organizationName: "",
  industry: "",
  companySize: "",
  country: "India",
  interests: [],
};

const roles: Option[] = ["HR", "Admin", "IT", "Founder / Owner", "Manager", "Other"].map((value) => ({ value, label: value }));
const industries: Option[] = ["Technology", "Manufacturing", "Retail", "Healthcare", "Education", "Finance", "Professional Services", "Other"].map((value) => ({ value, label: value }));
const companySizes: Option[] = ["1–25", "26–50", "51–100", "101–250", "251–500", "500+"].map((value) => ({ value, label: value }));
const interests = ["HR & employee management", "Attendance & leave", "Payroll", "Assets", "Devices", "Software management", "Remote support"];

const strengthLabels = ["", "Weak", "Fair", "Good", "Strong"];
const strengthScore = (password: string) => {
  if (!password) return 0;
  let score = password.length >= 8 ? 1 : 0;
  if (/[A-Z]/.test(password)) score += 1;
  if (/[0-9]/.test(password)) score += 1;
  if (/[^A-Za-z0-9]/.test(password)) score += 1;
  return Math.min(score, 4);
};

function StepProgress({ step }: { step: SignupStep }) {
  const steps = ["Account", "Organization", "Workspace"];
  return (
    <nav className="signup-progress" aria-label="Signup progress">
      {steps.map((label, index) => {
        const number = index + 1;
        const complete = number < step;
        const current = number === step;
        return (
          <div className="signup-progress-step" key={label}>
            <div className={`signup-progress-node ${complete ? "complete" : ""} ${current ? "current" : ""}`} aria-current={current ? "step" : undefined}>
              {complete ? <Check size={14} /> : `0${number}`}
            </div>
            <span>{label}</span>
            {index < steps.length - 1 && <span className={`signup-progress-line ${complete ? "complete" : ""}`} aria-hidden />}
          </div>
        );
      })}
    </nav>
  );
}

function FieldError({ id, message }: { id: string; message?: string }) {
  return message ? <p className="signup-field-error" id={id} role="alert">{message}</p> : null;
}

export function SignupFlow() {
  const reduce = useReducedMotion();
  const [step, setStep] = useState<SignupStep>(1);
  const [data, setData] = useState<SignupFormData>(initialData);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [showPassword, setShowPassword] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [integrationMessage, setIntegrationMessage] = useState("");
  const [created, setCreated] = useState(false);

  const update = (field: keyof SignupFormData, value: string | string[]) => {
    setData((current) => ({ ...current, [field]: value }));
    setErrors((current) => ({ ...current, [field]: "" }));
    setIntegrationMessage("");
  };

  const validateStep = (currentStep: SignupStep) => {
    const nextErrors: Record<string, string> = {};
    if (currentStep === 1) {
      if (!data.firstName.trim()) nextErrors.firstName = "Enter your first name.";
      if (!data.lastName.trim()) nextErrors.lastName = "Enter your last name.";
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) nextErrors.email = "Please enter a valid work email.";
      if (strengthScore(data.password) < 3) nextErrors.password = "Use at least 8 characters with a number and uppercase letter.";
    }
    if (currentStep === 2) {
      if (!data.organizationName.trim()) nextErrors.organizationName = "Enter your organization name.";
      if (!data.role) nextErrors.role = "Select your role.";
      if (!data.industry) nextErrors.industry = "Select an industry.";
      if (!data.companySize) nextErrors.companySize = "Select your company size.";
      if (!data.country) nextErrors.country = "Select your country.";
    }
    setErrors(nextErrors);
    return Object.keys(nextErrors).length === 0;
  };

  const next = () => {
    if (validateStep(step)) setStep((current) => Math.min(current + 1, 3) as SignupStep);
  };

  const createWorkspace = async () => {
    if (submitting) return;
    setIntegrationMessage("");
    setSubmitting(true);
    const endpoint = `${API_URL}/api/auth/register`;
    try {
      const response = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      const result = await response.json().catch(() => ({}));
      if (!response.ok) {
        if (response.status >= 500) throw new Error("Vettri is temporarily unavailable. Please try again in a moment.");
        throw new Error(result.message || result.details?.[0] || "Please check your details and try again.");
      }
      if (!result.accessToken || !result.refreshToken) throw new Error("We could not establish your Vettri session. Please try again.");
      window.localStorage.setItem("haodaone_access_token", result.accessToken);
      window.localStorage.setItem("haodaone_refresh_token", result.refreshToken);
      setCreated(true);
      window.setTimeout(() => window.location.assign(`${APP_URL}/onboarding`), 900);
    } catch (error) {
      setIntegrationMessage(error instanceof TypeError ? "We could not reach Vettri. Check your connection and try again." : error instanceof Error ? error.message : "We could not create your workspace. Please try again.");
      setSubmitting(false);
    }
  };

  const transition = reduce ? { duration: 0 } : { duration: 0.28, ease: [0.16, 1, 0.3, 1] as const };
  const passwordScore = strengthScore(data.password);

  return (
    <div className="signup-shell">
      <aside className="signup-brand-panel">
        <a className="signup-brand" href="/">vettri</a>
        <div className="signup-brand-copy">
          <span className="eyebrow inverse">Vettri workplace platform</span>
          <h1>HR meets workplace operations</h1>
          <p>One connected platform for your people, payroll, attendance, devices and software.</p>
        </div>
        <div className="signup-trial-note"><span /> <div><strong>14-day free trial</strong><small>No credit card required</small></div></div>
        <div className="signup-security-note"><ShieldCheck size={17} /><span>Your account details are handled securely.</span></div>
      </aside>

      <main className="signup-main">
        <div className="signup-form-wrap">
          <StepProgress step={step} />
          <div className="signup-form-card">
            <div className="signup-form-heading">
              <span className="eyebrow">Step 0{step}</span>
              <h2>{step === 1 ? "Create your Vettri account" : step === 2 ? "Tell us about your organization." : "Set up your workspace."}</h2>
              <p>{step === 1 ? "Start your 14-day free trial. No credit card required." : step === 2 ? "A little context helps us prepare the right workspace." : "Choose what you would like to manage first. You can change this later."}</p>
            </div>

            <AnimatePresence mode="wait" initial={false}>
              <motion.div key={step} initial={{ opacity: 0, x: reduce ? 0 : 10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: reduce ? 0 : -10 }} transition={transition}>
                {step === 1 && <AccountStep data={data} errors={errors} showPassword={showPassword} passwordScore={passwordScore} onUpdate={update} onTogglePassword={() => setShowPassword((value) => !value)} />}
                {step === 2 && <OrganizationStep data={data} errors={errors} onUpdate={update} />}
                {step === 3 && <WorkspaceStep data={data} onUpdate={update} />}
              </motion.div>
            </AnimatePresence>

            {integrationMessage && <p className="signup-submit-error" role="alert">{integrationMessage}</p>}
            {created && <div className="signup-created" role="status"><Check size={18} />Your Vettri workspace is ready.</div>}

            <div className="signup-form-actions">
              {step > 1 ? <button className="signup-back" type="button" onClick={() => setStep((current) => (current - 1) as SignupStep)} disabled={submitting}><ArrowLeft size={16} />Back</button> : <span />}
              {step < 3 ? <button className="btn btn-primary" type="button" onClick={next}>Continue <ArrowRight size={16} /></button> : <button className="btn btn-primary" type="button" onClick={createWorkspace} disabled={submitting || created}>{submitting ? "Creating your workspace…" : "Create my workspace"} <ArrowRight size={16} /></button>}
            </div>
            {step === 1 && <p className="signup-login-prompt">Already have an account? <a href={`${APP_URL}/login`}>Log in</a></p>}
          </div>
          <p className="signup-footer-note"><LockKeyhole size={14} /> No credit card required · Your trial starts when your workspace is created</p>
        </div>
      </main>
    </div>
  );
}

function AccountStep({ data, errors, showPassword, passwordScore, onUpdate, onTogglePassword }: { data: SignupFormData; errors: Record<string, string>; showPassword: boolean; passwordScore: number; onUpdate: (field: keyof SignupFormData, value: string) => void; onTogglePassword: () => void }) {
  return <div className="signup-fields">
    <div className="signup-field-row"><InputField id="firstName" label="First name" value={data.firstName} error={errors.firstName} onChange={(value) => onUpdate("firstName", value)} /><InputField id="lastName" label="Last name" value={data.lastName} error={errors.lastName} onChange={(value) => onUpdate("lastName", value)} /></div>
    <InputField id="email" label="Work email" type="email" value={data.email} error={errors.email} onChange={(value) => onUpdate("email", value)} />
    <div className="signup-input-group"><label htmlFor="password">Password</label><div className={`signup-password-input ${errors.password ? "has-error" : ""}`}><input id="password" type={showPassword ? "text" : "password"} value={data.password} aria-invalid={Boolean(errors.password)} aria-describedby={errors.password ? "password-error" : "password-strength"} onChange={(event) => onUpdate("password", event.target.value)} /><button type="button" onClick={onTogglePassword} aria-label={showPassword ? "Hide password" : "Show password"}>{showPassword ? <EyeOff size={17} /> : <Eye size={17} />}</button></div><div className="password-strength" id="password-strength" aria-live="polite"><span className={`password-strength-bar score-${passwordScore}`} /><span>{strengthLabels[passwordScore] || "Use 8+ characters"}</span></div><FieldError id="password-error" message={errors.password} /></div>
    <InputField id="role" label="Job role (optional)" value={data.role} onChange={(value) => onUpdate("role", value)} placeholder="e.g. People operations" />
  </div>;
}

function OrganizationStep({ data, errors, onUpdate }: { data: SignupFormData; errors: Record<string, string>; onUpdate: (field: keyof SignupFormData, value: string) => void }) {
  return <div className="signup-fields"><InputField id="organizationName" label="Organization name" value={data.organizationName} error={errors.organizationName} onChange={(value) => onUpdate("organizationName", value)} placeholder="e.g. Acme Technologies" /><SelectField id="role" label="Your role" value={data.role} options={roles} error={errors.role} onChange={(value) => onUpdate("role", value)} /><SelectField id="industry" label="Industry" value={data.industry} options={industries} error={errors.industry} onChange={(value) => onUpdate("industry", value)} /><SelectField id="companySize" label="Company size" value={data.companySize} options={companySizes} error={errors.companySize} onChange={(value) => onUpdate("companySize", value)} /><InputField id="country" label="Country" value={data.country} error={errors.country} onChange={(value) => onUpdate("country", value)} /> </div>;
}

function WorkspaceStep({ data, onUpdate }: { data: SignupFormData; onUpdate: (field: keyof SignupFormData, value: string[]) => void }) {
  return <div className="interest-grid">{interests.map((interest) => { const selected = data.interests.includes(interest); return <button className={`interest-option ${selected ? "selected" : ""}`} type="button" key={interest} aria-pressed={selected} onClick={() => onUpdate("interests", selected ? data.interests.filter((item) => item !== interest) : [...data.interests, interest])}><span>{selected ? <Check size={15} /> : null}</span>{interest}</button>; })}<p className="interest-note">You can change these later.</p></div>;
}

function InputField({ id, label, value, error, type = "text", placeholder, onChange }: { id: string; label: string; value: string; error?: string; type?: string; placeholder?: string; onChange: (value: string) => void }) {
  const errorId = `${id}-error`;
  return <div className="signup-input-group"><label htmlFor={id}>{label}</label><input id={id} type={type} value={value} placeholder={placeholder} aria-invalid={Boolean(error)} aria-describedby={error ? errorId : undefined} onChange={(event) => onChange(event.target.value)} className={error ? "has-error" : ""} /><FieldError id={errorId} message={error} /></div>;
}

function SelectField({ id, label, value, options, error, onChange }: { id: string; label: string; value: string; options: Option[]; error?: string; onChange: (value: string) => void }) {
  const errorId = `${id}-error`;
  return <div className="signup-input-group"><label htmlFor={id}>{label}</label><select id={id} value={value} aria-invalid={Boolean(error)} aria-describedby={error ? errorId : undefined} onChange={(event) => onChange(event.target.value)} className={error ? "has-error" : ""}><option value="">Select an option</option>{options.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}</select><FieldError id={errorId} message={error} /></div>;
}
