"use client";

import { motion } from "framer-motion";

export function PricingSwitch() {
  return (
    <div className="pricing-switch" aria-label="Billing period">
      <motion.span className="pricing-switch-thumb" layoutId="billing-thumb" transition={{ type: "spring", stiffness: 420, damping: 30 }} />
      <button className="pricing-switch-option active" type="button" aria-pressed="true">Monthly</button>
      <button className="pricing-switch-option" type="button" aria-pressed="false" disabled>Annual</button>
    </div>
  );
}
