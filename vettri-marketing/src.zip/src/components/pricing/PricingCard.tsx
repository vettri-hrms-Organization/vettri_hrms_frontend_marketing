"use client";

import { ArrowUpRight, Sparkles } from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";
import { APP_URL } from "@/lib/config";
import { formatPrice, type PricingPlan } from "@/data/pricing";
import { PricingFeatureList } from "./PricingFeatureList";

export function PricingCard({ plan, index }: { plan: PricingPlan; index: number }) {
  const href = plan.cta === "Talk to sales" ? "/contact" : "/signup";

  return (
    <motion.article
      className={`pricing-card pricing-card-${plan.id}`}
      initial={{ opacity: 0, y: 28 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.2 }}
      transition={{ duration: 0.65, delay: index * 0.1, ease: [0.16, 1, 0.3, 1] }}
    >
      {plan.popular && <span className="popular-label"><Sparkles size={13} />Most popular</span>}
      <div className="pricing-card-heading">
        <span className="pricing-plan-index">0{index + 1}</span>
        <h2>{plan.name}</h2>
        <p>{plan.description}</p>
      </div>
      <div className="pricing-price" aria-label={plan.priceMonthly ? `${formatPrice(plan.priceMonthly)} per month` : "Custom pricing"}>
        <AnimatePresence mode="popLayout" initial={false}>
          <motion.span key={plan.priceMonthly ?? "custom"} initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -14 }} transition={{ duration: 0.25 }}>
            {formatPrice(plan.priceMonthly)}
          </motion.span>
        </AnimatePresence>
        {plan.priceMonthly !== null && <small>/ month</small>}
      </div>
      {plan.employeeLimit && <p className="pricing-capacity">Up to {plan.employeeLimit} employees</p>}
      <PricingFeatureList groups={plan.featureGroups} />
      <a className={`btn ${plan.popular ? "btn-primary" : "btn-quiet"} pricing-card-cta`} href={href}>
        {plan.cta}<ArrowUpRight size={16} />
      </a>
    </motion.article>
  );
}
