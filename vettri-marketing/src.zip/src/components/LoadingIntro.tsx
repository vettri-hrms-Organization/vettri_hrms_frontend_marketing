"use client";

import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { useEffect, useRef, useState } from "react";

const SESSION_KEY = "vettri-intro-seen";
const MAX_VISIBLE_MS = 4400;

export function LoadingIntro() {
  const reduce = useReducedMotion();
  const [visible, setVisible] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (reduce) return;
    if (typeof window === "undefined") return;
    if (sessionStorage.getItem(SESSION_KEY)) return;

    setVisible(true);
    const dismiss = () => {
      sessionStorage.setItem(SESSION_KEY, "1");
      setVisible(false);
    };
    const failSafe = setTimeout(dismiss, MAX_VISIBLE_MS);
    const video = videoRef.current;
    video?.addEventListener("ended", dismiss);

    return () => {
      clearTimeout(failSafe);
      video?.removeEventListener("ended", dismiss);
    };
  }, [reduce]);

  if (reduce) return null;

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          className="intro-overlay"
          role="presentation"
          aria-hidden="true"
          initial={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        >
          <video
            ref={videoRef}
            className="intro-video"
            autoPlay
            muted
            playsInline
            preload="auto"
          >
            <source src="/brand/vettri-loading.webm" type="video/webm" />
            <source src="/brand/vettri-loading.mp4" type="video/mp4" />
          </video>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
