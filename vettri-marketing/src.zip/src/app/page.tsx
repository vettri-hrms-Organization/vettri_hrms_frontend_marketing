import Footer from "@/components/Footer";
import Navbar from "@/components/Navbar";
import { Hero } from "@/components/Hero";
import {
  AutomationSecurity,
  ConnectedSystem,
  EmployeeExperience,
  FinalCta,
  HrItDifference,
  Lifecycle,
  PricingPreview,
  SoftwareAndSupport,
  ValueStrip,
  WorkplaceTechnology,
} from "@/components/MarketingSections";

export default function Home() {
  return (
    <>
      <Navbar />
      <main>
        <Hero />
        <ValueStrip />
        <ConnectedSystem />
        <HrItDifference />
        <Lifecycle />
        <EmployeeExperience />
        <WorkplaceTechnology />
        <SoftwareAndSupport />
        <AutomationSecurity />
        <PricingPreview />
        <FinalCta />
      </main>
      <Footer />
    </>
  );
}
