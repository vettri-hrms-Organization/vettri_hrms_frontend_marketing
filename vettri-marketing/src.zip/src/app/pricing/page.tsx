import Footer from "@/components/Footer";
import Navbar from "@/components/Navbar";
import { PricingSection } from "@/components/pricing/PricingSection";

export default function PricingPage() {
  return <><Navbar /><PricingSection /><Footer /></>;
}
