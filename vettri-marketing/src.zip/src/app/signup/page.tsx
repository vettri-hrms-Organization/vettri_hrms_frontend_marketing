import type { Metadata } from "next";
import { SignupFlow } from "@/components/signup/SignupFlow";

export const metadata: Metadata = {
  title: "Create your Vettri account",
  description: "Start your 14-day Vettri free trial. No credit card required.",
};

export default function SignupPage() {
  return <SignupFlow />;
}
